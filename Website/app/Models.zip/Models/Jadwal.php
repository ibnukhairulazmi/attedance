<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Jadwal extends Model
{
    use HasFactory;

    protected $table = 'jadwal';

    protected $fillable = [
        'id_kelas',
        'id_dosen',
        'mata_kuliah',
        'hari',
        'waktu_mulai',
        'waktu_selesai',
        'is_active',
    ];

    protected function casts(): array
    {
        return ['is_active' => 'boolean'];
    }

    public function schoolClass(): BelongsTo
    {
        return $this->belongsTo(Kelas::class, 'id_kelas');
    }

    public function teacher(): BelongsTo
    {
        return $this->belongsTo(User::class, 'id_dosen');
    }

    public function sessions(): HasMany
    {
        return $this->hasMany(PresensiSession::class, 'id_jadwal');
    }

    public function activeSession(): HasOne
    {
        return $this->hasOne(PresensiSession::class, 'id_jadwal')
            ->where('tgl_sesi', today())
            ->where('status', 'aktif');
    }

    public function isActiveNow(): bool
    {
        $now = now()->format('H:i:s');
        $day = $this->getDayInIndonesian();

        return $this->is_active
            && $this->hari === $day
            && $now >= $this->waktu_mulai
            && $now <= $this->waktu_selesai;
    }

    private function getDayInIndonesian(): string
    {
        return match (now()->format('l')) {
            'Sunday'    => 'Minggu',
            'Monday'    => 'Senin',
            'Tuesday'   => 'Selasa',
            'Wednesday' => 'Rabu',
            'Thursday'  => 'Kamis',
            'Friday'    => 'Jumat',
            'Saturday'  => 'Sabtu',
            default     => '',
        };
    }
}
