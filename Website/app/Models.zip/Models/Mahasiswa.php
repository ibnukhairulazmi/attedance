<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Mahasiswa extends Model
{
    use HasFactory;

    protected $table = 'mahasiswa';

    protected $fillable = [
        'nama',
        'nim',
        'email',
        'password',
        'id_kelas',
        'device_id',
        'device_token',
        'is_locked',
        'api_token',
    ];

    protected $hidden = ['password', 'api_token'];

    protected function casts(): array
    {
        return [
            'is_locked' => 'boolean',
        ];
    }

    public function schoolClass(): BelongsTo
    {
        return $this->belongsTo(Kelas::class, 'id_kelas');
    }

    public function attendances(): HasMany
    {
        return $this->hasMany(Presensi::class, 'id_mahasiswa');
    }

    public function generateApiToken(): string
    {
        $token = Str::random(60);
        $this->update(['api_token' => hash('sha256', $token)]);
        return $token;
    }

    public function verifyToken(string $rawToken): bool
    {
        return $this->api_token === hash('sha256', $rawToken);
    }
}
