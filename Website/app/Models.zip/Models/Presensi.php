<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Presensi extends Model
{
    use HasFactory;

    protected $table = 'presensi';

    protected $fillable = [
        'id_sesi',
        'id_mahasiswa',
        'status',
        'scan_latitude',
        'scan_longitude',
        'jarak_meter',
        'scan_time',
        'ip_address',
    ];

    protected function casts(): array
    {
        return [
            'scan_time'      => 'datetime',
            'scan_latitude'  => 'float',
            'scan_longitude' => 'float',
        ];
    }

    public function session(): BelongsTo
    {
        return $this->belongsTo(PresensiSession::class, 'id_sesi');
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(Mahasiswa::class, 'id_mahasiswa');
    }
}
