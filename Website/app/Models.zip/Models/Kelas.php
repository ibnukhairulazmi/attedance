<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Kelas extends Model
{
    use HasFactory;

    protected $table = 'kelas';

    protected $fillable = ['nama_kelas', 'jurusan', 'angkatan'];

    public function students(): HasMany
    {
        return $this->hasMany(Mahasiswa::class, 'id_kelas');
    }

    public function schedules(): HasMany
    {
        return $this->hasMany(Jadwal::class, 'id_kelas');
    }
}
