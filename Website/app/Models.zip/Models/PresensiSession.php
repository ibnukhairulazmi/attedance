<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PresensiSession extends Model
{
    use HasFactory;

    protected $table = 'sesi_presensi';

    protected $fillable = [
        'id_jadwal',
        'qr_token',
        'qr_expires_at',
        'tgl_sesi',
        'kelas_latitude',
        'kelas_longitude',
        'status',
    ];

    protected function casts(): array
    {
        return [
            'qr_expires_at'   => 'datetime',
            'tgl_sesi'        => 'date',
            'kelas_latitude'  => 'float',
            'kelas_longitude' => 'float',
        ];
    }

    public function schedule(): BelongsTo
    {
        return $this->belongsTo(Jadwal::class, 'id_jadwal');
    }

    public function attendances(): HasMany
    {
        return $this->hasMany(Presensi::class, 'id_sesi');
    }

    public function isExpired(): bool
    {
        return now()->isAfter($this->qr_expires_at) || $this->status !== 'aktif';
    }

    public function presentCount(): int
    {
        return $this->attendances()->where('status', 'hadir')->count();
    }

    public function totalStudents(): int
    {
        return $this->schedule->schoolClass->students()->count();
    }
}
