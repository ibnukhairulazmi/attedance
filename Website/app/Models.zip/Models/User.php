<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Relations\HasMany;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

   
    protected $table = 'user';

    protected $fillable = [
        'nama',
        'email',
        'password',
        'nidn',
        'is_active',
    ];

    protected $hidden = ['password', 'remember_token'];

    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
        ];
    }

    public function schedules(): HasMany
    {
        return $this->hasMany(Jadwal::class, 'id_dosen');
    }

    public function todaySchedules()
    {
        $dayMap = [
            'Sunday'    => 'Minggu',
            'Monday'    => 'Senin',
            'Tuesday'   => 'Selasa',
            'Wednesday' => 'Rabu',
            'Thursday'  => 'Kamis',
            'Friday'    => 'Jumat',
            'Saturday'  => 'Sabtu',
        ];
        $day = $dayMap[now()->format('l')] ?? '';

        return $this->schedules()
            ->with(['schoolClass', 'activeSession'])
            ->where('hari', $day)
            ->where('is_active', true)
            ->orderBy('waktu_mulai')
            ->get();
    }
}
